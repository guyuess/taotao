create view v_score as
select `guyue`.`score`.`id`     AS `id`,
       `guyue`.`score`.`stu_id` AS `stu_id`,
       `guyue`.`score`.`c_name` AS `c_name`,
       `guyue`.`score`.`grade`  AS `grade`
from `guyue`.`score`;

